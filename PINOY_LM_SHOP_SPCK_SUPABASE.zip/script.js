/* PINOY LM SHOP - Supabase frontend
   Uses the existing shop_* tables. Never place a service-role key in this file. */
const SUPABASE_URL = "https://zgbcnetzoxeofjagpydy.supabase.co";
const SUPABASE_KEY = "sb_publishable_TK_z60RmKnalNC4a9GujYQ_3PJ9I1Tr";
const db = window.supabase.createClient(SUPABASE_URL, SUPABASE_KEY, {
  auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true }
});

const $ = id => document.getElementById(id);
let session = null, user = null, profile = null, wallet = null, products = [], isAdmin = false;
const money = n => "₱" + Number(n || 0).toLocaleString("en-PH",{minimumFractionDigits:2,maximumFractionDigits:2});
const esc = s => String(s ?? "").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
function message(text, error=false){$("appMessage").textContent=text||"";$("appMessage").className="message "+(error?"error":"success")}
function authMessage(text,error=false){$("authMessage").textContent=text||"";$("authMessage").className="message "+(error?"error":"success")}
function fail(err){console.error(err);message(err?.message || String(err),true)}
function showAuth(tab="login"){
  $("authView").classList.remove("hidden");$("appView").classList.add("hidden");$("topWallet").classList.add("hidden");$("logoutBtn").classList.add("hidden");
  document.querySelectorAll("[data-auth-tab]").forEach(b=>b.classList.toggle("active",b.dataset.authTab===tab));
  $("loginForm").classList.toggle("hidden",tab!=="login");$("signupForm").classList.toggle("hidden",tab!=="signup");
}
document.querySelectorAll("[data-auth-tab]").forEach(b=>b.addEventListener("click",()=>showAuth(b.dataset.authTab)));
$("logoutBtn").addEventListener("click",async()=>{await db.auth.signOut();session=user=profile=wallet=null;showAuth()});
document.querySelectorAll("#mainNav button[data-page]").forEach(b=>b.addEventListener("click",()=>goPage(b.dataset.page)));
document.querySelectorAll("[data-go]").forEach(b=>b.addEventListener("click",()=>goPage(b.dataset.go)));
function goPage(name){
  if(name==="admin"&&!isAdmin)return;
  document.querySelectorAll(".page").forEach(p=>p.classList.toggle("active",p.id==="page-"+name));
  document.querySelectorAll("#mainNav button").forEach(b=>b.classList.toggle("active",b.dataset.page===name));
  if(name==="shop")loadProducts(); if(name==="wallet"){loadTopups();loadWalletActivity()}
  if(name==="orders")loadOrders();if(name==="subscriptions")loadSubscriptions();if(name==="admin")loadAdmin();
}

$("loginForm").addEventListener("submit",async e=>{
  e.preventDefault();authMessage("Signing in…");
  const {data,error}=await db.auth.signInWithPassword({email:$("loginEmail").value.trim(),password:$("loginPassword").value});
  if(error)return authMessage(error.message,true);
  session=data.session;await startApp();
});
$("signupForm").addEventListener("submit",async e=>{
  e.preventDefault();authMessage("Creating account…");
  const email=$("signupEmail").value.trim(),password=$("signupPassword").value;
  const {data,error}=await db.auth.signUp({email,password,options:{data:{full_name:$("signupName").value.trim(),whatsapp:$("signupPhone").value.trim()}}});
  if(error)return authMessage(error.message,true);
  if(!data.session){authMessage("Account created. Email confirmation is enabled in Supabase. Disable Confirm email in Authentication settings for immediate activation, then log in.",false);return}
  session=data.session;await startApp();
});
async function startApp(){
  $("authView").classList.add("hidden");$("appView").classList.remove("hidden");$("topWallet").classList.remove("hidden");$("logoutBtn").classList.remove("hidden");
  user=session.user;
  const {data:p,error:pe}=await db.from("shop_profiles").select("user_id,full_name,whatsapp,role,created_at").eq("user_id",user.id).maybeSingle();
  if(pe)throw pe;
  if(!p){message("Your shop profile was not created by the Supabase auth trigger. Check shop_new_customer() and shop_auth_user_created.",true);return}
  profile=p;isAdmin=String(profile.role).toLowerCase()==="admin";
  $("welcomeName").textContent=profile.full_name||user.email;$("welcomeEmail").textContent=user.email;
  $("rolePill").textContent=isAdmin?"ADMIN":"CUSTOMER";$("adminNav").classList.toggle("hidden",!isAdmin);
  await loadWallet();await loadProducts();await loadOrders();goPage("dashboard");
}
async function loadWallet(){
  const {data,error}=await db.from("shop_wallets").select("balance").eq("user_id",user.id).maybeSingle();
  if(error)throw error;wallet=data||{balance:0};
  $("topWallet").textContent=money(wallet.balance);$("dashBalance").textContent=money(wallet.balance);$("walletBalance").textContent=money(wallet.balance);
}
async function loadProducts(){
  const {data,error}=await db.from("shop_products").select("id,name,description,category,price_php,product_type,duration_days,is_active").eq("is_active",true).order("created_at",{ascending:false});
  if(error)return fail(error);products=data||[];
  const {data:inv,error:ie}=await db.from("shop_inventory").select("product_id").eq("status","available");
  const inventory=ie?[]:(inv||[]);
  $("productList").innerHTML=products.length?products.map(p=>{
    const count=inventory.filter(i=>i.product_id===p.id).length;
    const isCode=String(p.product_type||"").toLowerCase().includes("code")||String(p.category).toLowerCase().includes("rss");
    return `<article class="card product-card"><div><span class="pill">${esc(p.category)}</span><h3>${esc(p.name)}</h3><p class="muted">${esc(p.description||"Digital product")}</p></div><div class="price">${money(p.price_php)}</div><div class="stock">${isCode?count+" code(s) in stock":(p.duration_days? p.duration_days+" days":"Available")}</div><button class="btn primary" data-buy="${p.id}">Buy now</button></article>`;
  }).join(""):`<div class="card empty">No active products are available yet.</div>`;
  $("productList").querySelectorAll("[data-buy]").forEach(b=>b.addEventListener("click",()=>purchase(b.dataset.buy)));
  $("stockProduct").innerHTML=products.map(p=>`<option value="${p.id}">${esc(p.name)}</option>`).join("");
}
async function purchase(productId){
  if(!confirm("Confirm purchase? The amount will be deducted from your wallet."))return;
  message("Processing purchase…");
  const {data,error}=await db.rpc("purchase_shop_product",{p_product_id:productId});
  if(error)return fail(error);
  message("Purchase submitted successfully.");
  await Promise.all([loadWallet(),loadOrders(),loadProducts()]);
}
$("refreshProducts").addEventListener("click",loadProducts);
$("topupForm").addEventListener("submit",async e=>{
  e.preventDefault();
  const amount=Number($("topupAmount").value),file=$("proofFile").files[0];
  if(amount<500)return message("Minimum top-up is ₱500.",true);
  if(!file)return message("Please upload your GCash payment screenshot.",true);
  if(!file.type.startsWith("image/"))return message("Screenshot must be an image file.",true);
  if(file.size>6*1024*1024)return message("Image must be 6 MB or smaller.",true);
  message("Uploading proof…");
  const safeName=file.name.replace(/[^a-zA-Z0-9._-]/g,"_");
  const path=`${user.id}/${Date.now()}_${safeName}`;
  const {error:uploadError}=await db.storage.from("payment-proofs").upload(path,file,{upsert:false,contentType:file.type});
  if(uploadError)return fail(uploadError);
  const {error}=await db.from("shop_topups").insert({
    user_id:user.id,amount,sender_name:$("senderName").value.trim(),
    sender_account:$("senderAccount").value.trim(),proof_url:path,status:"pending"
  });
  if(error){message("Top-up row was not saved. Uploaded proof remains in storage: "+error.message,true);return}
  $("topupForm").reset();message("Top-up submitted. Wait for admin verification.");await loadTopups();
});
async function loadTopups(){
  const {data,error}=await db.from("shop_topups").select("id,amount,sender_name,sender_account,proof_url,status,admin_note,created_at").eq("user_id",user.id).order("created_at",{ascending:false});
  if(error)return fail(error);
  $("myTopups").innerHTML=data?.length?data.map(t=>`<div class="list-row"><div><b>${money(t.amount)}</b> <span class="pill">${esc(t.status)}</span></div><p class="tiny">${esc(t.sender_name)} • Ref/account: ${esc(t.sender_account||"—")} • ${new Date(t.created_at).toLocaleString()}</p>${t.admin_note?`<p class="muted">${esc(t.admin_note)}</p>`:""}</div>`).join(""):`<div class="empty">No top-up requests yet.</div>`;
}
async function loadWalletActivity(){
  const {data,error}=await db.from("shop_wallet_transactions").select("amount,transaction_type,description,created_at").eq("user_id",user.id).order("created_at",{ascending:false}).limit(50);
  if(error)return fail(error);
  $("walletActivity").innerHTML=data?.length?data.map(t=>`<div class="list-row"><b>${esc(t.transaction_type)}</b><span class="price">${money(t.amount)}</span><p class="tiny">${esc(t.description||"")} • ${new Date(t.created_at).toLocaleString()}</p></div>`).join(""):`<div class="empty">No wallet activity.</div>`;
}
async function loadOrders(){
  const {data,error}=await db.from("shop_orders").select("id,total_amount,status,payment_method,created_at,shop_order_items(product_name,quantity,unit_price,subtotal)").eq("user_id",user.id).order("created_at",{ascending:false});
  if(error)return fail(error);
  $("dashOrders").textContent=data?.length||0;
  $("myOrders").innerHTML=data?.length?data.map(o=>`<div class="list-row"><div><b>Order #${esc(o.id.slice(0,8))}</b> <span class="pill">${esc(o.status)}</span></div><p class="price">${money(o.total_amount)}</p><p class="tiny">${new Date(o.created_at).toLocaleString()}</p>${(o.shop_order_items||[]).map(i=>`<p>${esc(i.product_name)} × ${i.quantity} — ${money(i.subtotal)}</p>`).join("")}</div>`).join(""):`<div class="empty">No orders yet.</div>`;
}
async function loadSubscriptions(){
  const {data,error}=await db.from("shop_subscriptions").select("id,product_id,order_id,status,starts_at,expires_at,next_billing_at,auto_renew,shop_products(name)").eq("user_id",user.id).order("created_at",{ascending:false});
  if(error)return fail(error);
  $("mySubscriptions").innerHTML=data?.length?data.map(s=>`<div class="list-row"><b>${esc(s.shop_products?.name||"Subscription")}</b> <span class="pill">${esc(s.status)}</span><p class="tiny">Expires: ${s.expires_at?new Date(s.expires_at).toLocaleString():"Not activated"}</p><label class="check-inline"><input type="checkbox" data-renew="${s.id}" ${s.auto_renew?"checked":""}> Automatic wallet renewal</label></div>`).join(""):`<div class="empty">No subscriptions yet.</div>`;
  $("mySubscriptions").querySelectorAll("[data-renew]").forEach(el=>el.addEventListener("change",async()=>{
    const {error}=await db.from("shop_subscriptions").update({auto_renew:el.checked}).eq("id",el.dataset.renew).eq("user_id",user.id);
    if(error){el.checked=!el.checked;return fail(error)}message("Auto-renew preference updated.");
  }));
}
async function loadAdmin(){
  if(!isAdmin)return;
  message("Loading admin dashboard…");
  // This RPC is the existing admin customer-list routine created in the database.
  const [{data:customers,error:ce},{data:topups,error:te}]=await Promise.all([
    db.rpc("admin_shop_customers"),
    db.from("shop_topups").select("id,user_id,amount,sender_name,sender_account,proof_url,status,created_at").eq("status","pending").order("created_at",{ascending:true})
  ]);
  if(ce)return fail(ce);if(te)return fail(te);
  $("adminCustomerCount").textContent=customers?.length||0;$("adminPendingCount").textContent=topups?.length||0;
  $("adminCustomers").innerHTML=customers?.length?customers.map(c=>`<div class="list-row"><b>${esc(c.full_name||c.email||c.user_id)}</b><p class="tiny">${esc(c.whatsapp||"")} • ${esc(c.status||c.role||"customer")}</p><div class="row-actions"><button class="btn secondary" data-customer-status="${c.user_id}" data-status="${String(c.status||"active")==="active"?"suspended":"active"}">${String(c.status||"active")==="active"?"Suspend":"Activate"}</button></div></div>`).join(""):`<div class="empty">No customers found.</div>`;
  $("adminCustomers").querySelectorAll("[data-customer-status]").forEach(b=>b.addEventListener("click",async()=>{
    const {error}=await db.rpc("admin_set_customer_status",{p_user_id:b.dataset.customerStatus,p_status:b.dataset.status});
    if(error)return fail(error);await loadAdmin();
  }));
  $("adminTopups").innerHTML=topups?.length?topups.map(t=>`<div class="list-row"><div><b>${money(t.amount)}</b> • ${esc(t.sender_name)}</div><p class="tiny">${esc(t.sender_account||"")} • ${new Date(t.created_at).toLocaleString()}</p><button class="btn secondary" data-proof="${esc(t.proof_url)}">View proof</button><div class="row-actions"><button class="btn primary" data-review="${t.id}" data-decision="approved">Approve</button><button class="btn secondary" data-review="${t.id}" data-decision="rejected">Reject</button></div></div>`).join(""):`<div class="empty">No pending top-ups.</div>`;
  $("adminTopups").querySelectorAll("[data-proof]").forEach(b=>b.addEventListener("click",async()=>{
    const {data,error}=await db.storage.from("payment-proofs").createSignedUrl(b.dataset.proof,300);
    if(error)return fail(error);window.open(data.signedUrl,"_blank","noopener");
  }));
  $("adminTopups").querySelectorAll("[data-review]").forEach(b=>b.addEventListener("click",async()=>{
    const note=prompt("Admin note (optional):")||"";
    // Atomic wallet credit + top-up status update must be performed server-side.
    const {error}=await db.rpc("admin_review_shop_topup",{p_topup_id:b.dataset.review,p_decision:b.dataset.decision,p_admin_note:note});
    if(error)return fail(error);
    message("Top-up "+b.dataset.decision+".");await loadAdmin();await loadWallet();
  }));
  message("");
}
$("adminRefresh").addEventListener("click",loadAdmin);
$("addProductForm").addEventListener("submit",async e=>{
  e.preventDefault();if(!isAdmin)return;
  const row={name:$("newProductName").value.trim(),category:$("newProductCategory").value.trim(),price_php:Number($("newProductPrice").value),product_type:$("newProductType").value,description:$("newProductDescription").value.trim()||null,duration_days:$("newProductDuration").value?Number($("newProductDuration").value):null,supplier_cost_usd:$("newProductCost").value?Number($("newProductCost").value):null,exchange_rate:$("newProductRate").value?Number($("newProductRate").value):null,is_active:true};
  const {error}=await db.from("shop_products").insert(row);if(error)return fail(error);
  e.target.reset();message("Product added.");await loadProducts();
});
$("addStockForm").addEventListener("submit",async e=>{
  e.preventDefault();if(!isAdmin)return;
  const {error}=await db.from("shop_inventory").insert({product_id:$("stockProduct").value,code:$("stockCode").value.trim(),status:"available"});
  if(error)return fail(error);e.target.reset();message("Inventory code added.");await loadProducts();
});
async function boot(){
  const {data,error}=await db.auth.getSession();if(error)return fail(error);
  session=data.session;
  if(session){user=session.user;try{await startApp()}catch(e){fail(e)}}
  else showAuth();
  db.auth.onAuthStateChange(async(event,newSession)=>{
    if(event==="SIGNED_OUT"){session=user=profile=wallet=null;showAuth()}
    else if(event==="SIGNED_IN"&&newSession&&!session){session=newSession;user=newSession.user;try{await startApp()}catch(e){fail(e)}}
  });
}
boot().catch(fail);
